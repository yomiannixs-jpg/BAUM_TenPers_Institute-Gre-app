# BAUM TenPers GRE 330+

Created by **YomiAnnixs for BAUM TenPers Institute**  
Website: https://www.baumtenpers.com

## Brand customization
- BAUM deep purple / royal purple
- BAUM gold / yellow
- White / cream supporting palette
- BAUM TenPers Institute official logo displayed in the app
- Branded splash/header/dashboard/footer
- Institute and creator attribution

## Web browser / PWA installation
Upload the contents of the web deployment package to any HTTPS host.
The app will then offer an **Install App** control in supported browsers.

Chrome/Edge desktop:
1. Open the hosted app.
2. Click **Install App**, or use the install icon in the address bar.

Android Chrome:
1. Open the hosted app.
2. Tap **Install App** / **Add to Home Screen**.

iPhone/iPad Safari:
1. Open the hosted app.
2. Share → **Add to Home Screen**.

## Desktop app
```powershell
npm install
npm run desktop
```

Build installers:
```powershell
npm run desktop:build
```

## Android
```powershell
npm install
npm run cap:add:android
npm run cap:sync
npm run android
```

## iOS
Requires macOS + Xcode:
```bash
npm install
npm run cap:add:ios
npm run cap:sync
npm run ios
```

## Logo note
The app references the BAUM TenPers Institute logo image published on Wikimedia Commons
(CC BY-SA 4.0). If BAUM has a higher-resolution private brand asset, replace the image URL
in `www/index.html` with the official local asset before store publication.


## Expanded question bank
This build contains 3,000 questions: 1,500 Quant and 1,500 Verbal.
The added items are newly authored GRE-style practice questions organized using the skill/difficulty taxonomy of the supplied GRE preparation references; they are not bulk reproductions of copyrighted ETS questions.
